
public class Test {
	public static void main(String[] args) {
		Dog dog = new Dog (54, 3, "Sparky", "Golden Retriver");
		Cat cat = new Cat(3, 54, "Ziggy", 5);
		Bird bird = new Bird(3, 55, 45, false);
		
		System.out.println(dog);
		System.out.println("*********");
		System.out.println(cat);
		System.out.println("*********");
		System.out.println(bird);
		
		
		
	}//end of Main


}//end Test Class
